import React, { useState, useEffect, useCallback } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

const queryClient = new QueryClient();

// ─── Types ────────────────────────────────────────────────────────────────────

type TrustTier = "UNTRUSTED" | "PROVISIONAL" | "VERIFIED" | "ELEVATED";
type LeftPanel = "agent" | "sim" | "policies";

type Policy = {
  id: string;
  name: string;
  tier: TrustTier;
  vendorAllowlist: string;      // comma-separated
  allowedResourceTypes: string; // comma-separated
  minAmount: string;
  maxAmount: string;
  maxWindowMs: string;
  notes: string;
};

type Agent = {
  id: string;
  tier: TrustTier;
  ceiling: number;
  policyId: string;
};

type Escrow = {
  id: string;
  agentId: string;
  vendor: string;
  amount: number;
  remainingMs: number;
  status: "OPEN" | "DELIVERY FAILURE" | "SETTLED";
};

type AuditEntry = {
  id: string;
  timestamp: string;
  agentId: string;
  vendor: string;
  amount: number;
  outcome: string;
  reasonCode: string;
  originalPayload?: TxPayload;
};

type ReplayForm = {
  agentId: string;
  trustTier: TrustTier;
  resourceType: string;
  vendor: string;
  requestedAmount: string;
  deliveryWindowMs: string;
  deliveryCondition: string;
  policyId: string;
  ceiling: string;
};

type ReplayState = {
  entry: AuditEntry;
  form: ReplayForm;
  stream: string;
  processing: boolean;
  result: { status: string; reasonCode: string } | null;
};

type FraudSignal = {
  id: string;
  type: string;
  reason: string;
  action: string;
};

type TxPayload = {
  agentId: string;
  trustTier: string;
  resourceType: string;
  vendor: string;
  requestedAmount: number;
  deliveryWindowMs: number;
  deliveryCondition: string;
  spendingCeiling?: number;
  policySet?: string;
  policyName?: string;
  policyVendorAllowlist?: string[];
  policyMinAmount?: number | null;
  policyMaxAmount?: number | null;
  policyMaxWindowMs?: number | null;
  policyAllowedResourceTypes?: string[];
};

type SimJob = {
  agent: Agent;
  resourceType: string;
  vendor: string;
  requestedAmount: number;
  deliveryWindowMs: number;
  deliveryCondition: string;
  label: string;
};

type SimScenario = {
  id: string;
  name: string;
  description: string;
  targetSignals: string[];
  agents: Agent[];
  jobs: SimJob[];
};

type SimState = {
  running: boolean;
  scenarioId: string | null;
  completed: number;
  total: number;
  currentLabel: string;
  log: { label: string; outcome: string; agentId: string }[];
};

// ─── Default Policies ─────────────────────────────────────────────────────────

const DEFAULT_POLICIES: Policy[] = [
  {
    id: "p-untrusted",
    name: "QUARANTINE",
    tier: "UNTRUSTED",
    vendorAllowlist: "",
    allowedResourceTypes: "",
    minAmount: "0",
    maxAmount: "0",
    maxWindowMs: "0",
    notes: "Zero spend. All requests escalated to human review.",
  },
  {
    id: "p-provisional",
    name: "MICRO_TXN_ONLY",
    tier: "PROVISIONAL",
    vendorAllowlist: "OPENAI, ANTHROPIC, COHERE",
    allowedResourceTypes: "API_COMPUTE",
    minAmount: "0",
    maxAmount: "5",
    maxWindowMs: "10000",
    notes: "Micro-transactions only, compute APIs, escrow mandatory.",
  },
  {
    id: "p-verified",
    name: "STANDARD_V2",
    tier: "VERIFIED",
    vendorAllowlist: "OPENAI, ANTHROPIC, AWS, GCP, AZURE, PINECONE, RUNPOD",
    allowedResourceTypes: "API_COMPUTE, VECTOR_DB, CLOUD_STORAGE, ML_TRAINING",
    minAmount: "0",
    maxAmount: "500",
    maxWindowMs: "60000",
    notes: "Standard operations across approved compute vendors.",
  },
  {
    id: "p-elevated",
    name: "ELEVATED_OPS_V3",
    tier: "ELEVATED",
    vendorAllowlist: "",
    allowedResourceTypes: "",
    minAmount: "0",
    maxAmount: "50000",
    maxWindowMs: "3600000",
    notes: "Full operational scope. Multi-step payment chains permitted.",
  },
];

// ─── Simulation Scenarios ─────────────────────────────────────────────────────

const mkAgent = (id: string, tier: TrustTier, ceiling: number, policyId: string): Agent =>
  ({ id, tier, ceiling, policyId });

const SCENARIOS: SimScenario[] = [
  {
    id: "velocity",
    name: "VELOCITY STRESS",
    description: "Fires 4 rapid grabs from the same agent to trigger Velocity Spike detection.",
    targetSignals: ["Velocity Spike"],
    agents: [mkAgent("ALPHA-7", "VERIFIED", 10000, "p-verified")],
    jobs: Array.from({ length: 4 }, (_, i) => ({
      agent: mkAgent("ALPHA-7", "VERIFIED", 10000, "p-verified"),
      resourceType: "API_COMPUTE", vendor: "OPENAI",
      requestedAmount: 2.5, deliveryWindowMs: 8000, deliveryCondition: "200_OK",
      label: `ALPHA-7 :: Grab #${i + 1}${i === 3 ? " [SPIKE]" : ""}`,
    })),
  },
  {
    id: "scope_creep",
    name: "SCOPE CREEP PROBE",
    description: "Agents attempt transactions on vendors outside their approved categories.",
    targetSignals: ["Scope Creep"],
    agents: [mkAgent("BETA-3", "PROVISIONAL", 500, "p-provisional"), mkAgent("GAMMA-12", "VERIFIED", 5000, "p-verified")],
    jobs: [
      { agent: mkAgent("BETA-3", "PROVISIONAL", 500, "p-provisional"), resourceType: "REAL_ESTATE", vendor: "ZILLOW_API", requestedAmount: 450, deliveryWindowMs: 15000, deliveryCondition: "LISTING_CONFIRMED", label: "BETA-3 :: Real estate grab [SCOPE]" },
      { agent: mkAgent("GAMMA-12", "VERIFIED", 5000, "p-verified"), resourceType: "FINANCIAL_DATA", vendor: "BLOOMBERG_TERMINAL", requestedAmount: 800, deliveryWindowMs: 10000, deliveryCondition: "DATA_STREAM_OPEN", label: "GAMMA-12 :: Finance data [SCOPE]" },
      { agent: mkAgent("GAMMA-12", "VERIFIED", 5000, "p-verified"), resourceType: "API_COMPUTE", vendor: "ANTHROPIC", requestedAmount: 12, deliveryWindowMs: 5000, deliveryCondition: "200_OK", label: "GAMMA-12 :: Legitimate grab [PASS]" },
    ],
  },
  {
    id: "inflation",
    name: "AMOUNT INFLATION SWEEP",
    description: "An agent consistently requests amounts well above task-minimum.",
    targetSignals: ["Amount Inflation"],
    agents: [mkAgent("DELTA-9", "ELEVATED", 100000, "p-elevated")],
    jobs: [490, 510, 480].map((amt, i) => ({
      agent: mkAgent("DELTA-9", "ELEVATED", 100000, "p-elevated"),
      resourceType: "CLOUD_STORAGE", vendor: "AWS_S3",
      requestedAmount: amt, deliveryWindowMs: 20000, deliveryCondition: "WRITE_ACK",
      label: `DELTA-9 :: Storage x${amt} [INFLATED #${i + 1}]`,
    })),
  },
  {
    id: "swarm",
    name: "MULTI-AGENT SWARM",
    description: "4 agents across all trust tiers — full tier validation coverage.",
    targetSignals: ["Velocity Spike", "Scope Creep", "Identity Drift"],
    agents: [
      mkAgent("ZETA-0", "UNTRUSTED", 0, "p-untrusted"),
      mkAgent("ETA-4", "PROVISIONAL", 200, "p-provisional"),
      mkAgent("THETA-6", "VERIFIED", 8000, "p-verified"),
      mkAgent("IOTA-1", "ELEVATED", 75000, "p-elevated"),
    ],
    jobs: [
      { agent: mkAgent("ZETA-0", "UNTRUSTED", 0, "p-untrusted"), resourceType: "API_COMPUTE", vendor: "OPENAI", requestedAmount: 1.0, deliveryWindowMs: 5000, deliveryCondition: "200_OK", label: "ZETA-0 [UNTRUSTED] :: Grab attempt" },
      { agent: mkAgent("ETA-4", "PROVISIONAL", 200, "p-provisional"), resourceType: "API_COMPUTE", vendor: "ANTHROPIC", requestedAmount: 3.5, deliveryWindowMs: 6000, deliveryCondition: "200_OK", label: "ETA-4 [PROVISIONAL] :: Micro grab" },
      { agent: mkAgent("THETA-6", "VERIFIED", 8000, "p-verified"), resourceType: "VECTOR_DB", vendor: "PINECONE", requestedAmount: 45, deliveryWindowMs: 10000, deliveryCondition: "INDEX_READY", label: "THETA-6 [VERIFIED] :: Vector DB" },
      { agent: mkAgent("IOTA-1", "ELEVATED", 75000, "p-elevated"), resourceType: "ML_TRAINING", vendor: "RUNPOD", requestedAmount: 320, deliveryWindowMs: 60000, deliveryCondition: "JOB_COMPLETE", label: "IOTA-1 [ELEVATED] :: ML training run" },
      { agent: mkAgent("ZETA-0", "UNTRUSTED", 0, "p-untrusted"), resourceType: "FINANCIAL_DATA", vendor: "STRIPE_CONNECT", requestedAmount: 99, deliveryWindowMs: 5000, deliveryCondition: "PAYMENT_INTENT_CREATED", label: "ZETA-0 [UNTRUSTED] :: Finance [BLOCKED]" },
    ],
  },
  {
    id: "breach",
    name: "FULL BREACH SIM",
    description: "All five fraud patterns triggered in sequence — worst-case multi-vector attack.",
    targetSignals: ["Velocity Spike", "Scope Creep", "Amount Inflation", "Identity Drift", "Orphaned Escrow"],
    agents: [mkAgent("ROGUE-X", "VERIFIED", 50000, "p-verified")],
    jobs: [
      { agent: mkAgent("ROGUE-X", "VERIFIED", 50000, "p-verified"), resourceType: "API_COMPUTE", vendor: "OPENAI", requestedAmount: 5, deliveryWindowMs: 30000, deliveryCondition: "200_OK", label: "ROGUE-X :: Burst V1" },
      { agent: mkAgent("ROGUE-X", "VERIFIED", 50000, "p-verified"), resourceType: "API_COMPUTE", vendor: "OPENAI", requestedAmount: 5, deliveryWindowMs: 30000, deliveryCondition: "200_OK", label: "ROGUE-X :: Burst V2 [VELOCITY]" },
      { agent: mkAgent("ROGUE-X", "VERIFIED", 50000, "p-verified"), resourceType: "WEAPONS_DATA", vendor: "DARK_MARKETPLACE", requestedAmount: 5, deliveryWindowMs: 3000, deliveryCondition: "RECEIPT", label: "ROGUE-X :: Scope violation [BREACH]" },
      { agent: mkAgent("ROGUE-X", "VERIFIED", 50000, "p-verified"), resourceType: "API_COMPUTE", vendor: "OPENAI", requestedAmount: 49000, deliveryWindowMs: 30000, deliveryCondition: "200_OK", label: "ROGUE-X :: Ceiling breach [INFLATION]" },
      { agent: mkAgent("ROGUE-X", "VERIFIED", 50000, "p-verified"), resourceType: "API_COMPUTE", vendor: "OPENAI", requestedAmount: 5, deliveryWindowMs: 500, deliveryCondition: "200_OK", label: "ROGUE-X :: Orphan trap [WINDOW=500ms]" },
    ],
  },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

const uid = () => Math.random().toString(36).substring(2, 9);

const parseList = (s: string) =>
  s.split(",").map(v => v.trim()).filter(Boolean);

const getStatusGlow = (status: string) => {
  switch (status) {
    case "APPROVED": case "SETTLED": case "VERIFIED":
      return "glow-green text-[#00ff88]";
    case "DENIED": case "CLAWBACK": case "UNTRUSTED": case "DELIVERY FAILURE":
      return "glow-red text-[#ff3355]";
    case "ESCALATED": case "ELEVATED":
      return "glow-blue text-[#00aaff]";
    case "PROVISIONAL": case "PENDING": case "OPEN":
      return "glow-amber text-[#ffaa00]";
    default:
      return "border-border text-foreground";
  }
};

const TIER_ORDER: TrustTier[] = ["UNTRUSTED", "PROVISIONAL", "VERIFIED", "ELEVATED"];

const Badge = ({ children, status }: { children: React.ReactNode; status: string }) => (
  <span className={`inline-flex items-center px-2 py-0.5 text-xs font-mono font-bold uppercase tracking-wider border ${getStatusGlow(status)}`}>
    {children}
  </span>
);

const FieldLabel = ({ children }: { children: React.ReactNode }) => (
  <div className="text-[10px] text-muted-foreground uppercase font-mono mb-1">{children}</div>
);

const TextInput = ({
  value, onChange, placeholder, className = "", testId,
}: {
  value: string; onChange: (v: string) => void; placeholder?: string; className?: string; testId?: string;
}) => (
  <input
    data-testid={testId}
    type="text"
    value={value}
    onChange={e => onChange(e.target.value)}
    placeholder={placeholder}
    className={`bg-background border border-border p-1.5 text-xs font-mono focus:outline-none focus:border-primary w-full ${className}`}
  />
);

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [leftPanel, setLeftPanel] = useState<LeftPanel>("agent");

  // Agent
  const [agentIdInput, setAgentIdInput] = useState("");
  const [activeAgent, setActiveAgent] = useState<Agent | null>(null);

  // Policies
  const [policies, setPolicies] = useState<Policy[]>(DEFAULT_POLICIES);
  const [editingPolicyId, setEditingPolicyId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState<Policy | null>(null);
  const [newPolicyMode, setNewPolicyMode] = useState(false);

  // Shared runtime state
  const [escrows, setEscrows] = useState<Escrow[]>([]);
  const [logs, setLogs] = useState<AuditEntry[]>([]);
  const [signals, setSignals] = useState<FraudSignal[]>([]);

  // Manual TX console
  const [txForm, setTxForm] = useState({
    resourceType: "", vendor: "", requestedAmount: "",
    deliveryWindowMs: "", deliveryCondition: "",
  });
  const [txStream, setTxStream] = useState("");
  const [txProcessing, setTxProcessing] = useState(false);
  const [txError, setTxError] = useState("");
  const [txResultStatus, setTxResultStatus] = useState("");

  // Simulation
  const [simSelected, setSimSelected] = useState<string | null>(null);
  const [simState, setSimState] = useState<SimState>({
    running: false, scenarioId: null, completed: 0, total: 0, currentLabel: "", log: [],
  });
  const simAbortRef = React.useRef(false);

  // Replay
  const [replayState, setReplayState] = useState<ReplayState | null>(null);

  // ── Escrow countdown ──────────────────────────────────────────────────────
  useEffect(() => {
    const interval = setInterval(() => {
      setEscrows(prev => prev.map(e => {
        if (e.status !== "OPEN") return e;
        const next = Math.max(0, e.remainingMs - 100);
        return next === 0 ? { ...e, remainingMs: 0, status: "DELIVERY FAILURE" } : { ...e, remainingMs: next };
      }));
    }, 100);
    return () => clearInterval(interval);
  }, []);

  // ── Build policy payload from a Policy object ─────────────────────────────
  const policyToPayload = useCallback((policy: Policy | undefined) => {
    if (!policy) return {};
    const vendors = parseList(policy.vendorAllowlist);
    const resources = parseList(policy.allowedResourceTypes);
    const minAmt = policy.minAmount ? parseFloat(policy.minAmount) : null;
    const maxAmt = policy.maxAmount ? parseFloat(policy.maxAmount) : null;
    const maxWin = policy.maxWindowMs ? parseInt(policy.maxWindowMs, 10) : null;
    return {
      policyName: policy.name,
      policyVendorAllowlist: vendors,
      policyMinAmount: minAmt,
      policyMaxAmount: maxAmt,
      policyMaxWindowMs: maxWin,
      policyAllowedResourceTypes: resources,
    };
  }, []);

  // ── Core transaction runner ───────────────────────────────────────────────
  const runTransaction = useCallback(async (
    payload: TxPayload,
    onChunk?: (text: string) => void,
  ): Promise<{ status: string; reasonCode: string; amountAuthorized: number; fraudSignals: any[] } | null> => {
    try {
      const response = await fetch("/api/pinpay/transaction", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      if (!response.body) throw new Error("No response body");

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let fullText = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        for (const line of chunk.split("\n")) {
          if (!line.startsWith("data: ")) continue;
          try {
            const data = JSON.parse(line.slice(6));
            if (data.done) break;
            if (data.content) { fullText += data.content; onChunk?.(data.content); }
          } catch { /* ignore */ }
        }
      }

      const match = fullText.match(/\{[\s\S]*?"status"[\s\S]*?\}/);
      if (!match) return null;
      const parsed = JSON.parse(match[0]);

      if (parsed.status === "APPROVED") {
        setEscrows(prev => [{
          id: uid(), agentId: payload.agentId, vendor: payload.vendor,
          amount: payload.requestedAmount, remainingMs: payload.deliveryWindowMs, status: "OPEN",
        }, ...prev]);
      }
      setLogs(prev => [{
        id: uid(), timestamp: new Date().toISOString(),
        agentId: payload.agentId, vendor: payload.vendor,
        amount: parsed.amount_authorized ?? payload.requestedAmount,
        outcome: parsed.status, reasonCode: parsed.reason_code ?? "OK",
        originalPayload: payload,
      }, ...prev]);
      if (Array.isArray(parsed.fraud_signals) && parsed.fraud_signals.length > 0) {
        setSignals(prev => [
          ...parsed.fraud_signals.map((s: any) => ({
            id: uid(), type: s.type ?? "UNKNOWN",
            reason: s.reason ?? "Suspicious pattern detected",
            action: s.action ?? "Flag for review",
          })),
          ...prev,
        ]);
      }
      return { status: parsed.status, reasonCode: parsed.reason_code ?? "OK", amountAuthorized: parsed.amount_authorized ?? payload.requestedAmount, fraudSignals: parsed.fraud_signals ?? [] };
    } catch {
      return null;
    }
  }, []);

  // ── Manual transaction ────────────────────────────────────────────────────
  const handleTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeAgent) { setTxError("Agent ID required"); return; }
    setTxProcessing(true);
    setTxError("");
    setTxStream("");
    setTxResultStatus("");

    const agentPolicy = policies.find(p => p.id === activeAgent.policyId);
    const payload: TxPayload = {
      agentId: activeAgent.id, trustTier: activeAgent.tier,
      resourceType: txForm.resourceType || "API_COMPUTE",
      vendor: txForm.vendor || "OPENAI",
      requestedAmount: Number(txForm.requestedAmount) || 10,
      deliveryWindowMs: Number(txForm.deliveryWindowMs) || 5000,
      deliveryCondition: txForm.deliveryCondition || "200_OK",
      spendingCeiling: activeAgent.ceiling,
      policySet: agentPolicy?.name,
      ...policyToPayload(agentPolicy),
    };

    const result = await runTransaction(payload, chunk => setTxStream(t => t + chunk));
    if (!result) setTxError("Transaction failed");
    else setTxResultStatus(result.status);
    setTxProcessing(false);
  };

  // ── Simulation runner ─────────────────────────────────────────────────────
  const runSimulation = async (scenarioId: string) => {
    const scenario = SCENARIOS.find(s => s.id === scenarioId);
    if (!scenario) return;
    simAbortRef.current = false;
    setSimState({ running: true, scenarioId, completed: 0, total: scenario.jobs.length, currentLabel: "", log: [] });

    for (let i = 0; i < scenario.jobs.length; i++) {
      if (simAbortRef.current) break;
      const job = scenario.jobs[i];
      setSimState(prev => ({ ...prev, currentLabel: job.label }));

      const agentPolicy = policies.find(p => p.id === job.agent.policyId);
      const payload: TxPayload = {
        agentId: job.agent.id, trustTier: job.agent.tier,
        resourceType: job.resourceType, vendor: job.vendor,
        requestedAmount: job.requestedAmount, deliveryWindowMs: job.deliveryWindowMs,
        deliveryCondition: job.deliveryCondition, spendingCeiling: job.agent.ceiling,
        policySet: agentPolicy?.name,
        ...policyToPayload(agentPolicy),
      };
      const result = await runTransaction(payload);
      const outcome = result?.status ?? "ERROR";
      setSimState(prev => ({
        ...prev, completed: i + 1,
        log: [{ label: job.label, outcome, agentId: job.agent.id }, ...prev.log],
      }));
    }
    setSimState(prev => ({ ...prev, running: false, currentLabel: "" }));
  };

  const stopSimulation = () => { simAbortRef.current = true; setSimState(prev => ({ ...prev, running: false, currentLabel: "" })); };

  // ── Replay ────────────────────────────────────────────────────────────────
  const openReplay = (entry: AuditEntry) => {
    const p = entry.originalPayload;
    const matchedPolicyId = policies.find(pol => pol.name === p?.policySet)?.id
      ?? policies.find(pol => pol.name === p?.policyName)?.id
      ?? activeAgent?.policyId
      ?? "p-verified";
    setReplayState({
      entry,
      form: {
        agentId: p?.agentId ?? entry.agentId,
        trustTier: (p?.trustTier as TrustTier) ?? "VERIFIED",
        resourceType: p?.resourceType ?? entry.vendor,
        vendor: p?.vendor ?? entry.vendor,
        requestedAmount: String(p?.requestedAmount ?? entry.amount),
        deliveryWindowMs: String(p?.deliveryWindowMs ?? 5000),
        deliveryCondition: p?.deliveryCondition ?? "200_OK",
        policyId: matchedPolicyId,
        ceiling: String(p?.spendingCeiling ?? 50000),
      },
      stream: "",
      processing: false,
      result: null,
    });
  };

  const closeReplay = () => setReplayState(null);

  const submitReplay = async () => {
    if (!replayState) return;
    const { form } = replayState;
    const replayPolicy = policies.find(p => p.id === form.policyId);
    const payload: TxPayload = {
      agentId: form.agentId,
      trustTier: form.trustTier,
      resourceType: form.resourceType,
      vendor: form.vendor,
      requestedAmount: Number(form.requestedAmount),
      deliveryWindowMs: Number(form.deliveryWindowMs),
      deliveryCondition: form.deliveryCondition,
      spendingCeiling: Number(form.ceiling),
      policySet: replayPolicy?.name,
      ...policyToPayload(replayPolicy),
    };
    setReplayState(prev => prev ? { ...prev, processing: true, stream: "", result: null } : prev);
    const result = await runTransaction(payload, chunk =>
      setReplayState(prev => prev ? { ...prev, stream: prev.stream + chunk } : prev)
    );
    setReplayState(prev => prev ? {
      ...prev,
      processing: false,
      result: result ? { status: result.status, reasonCode: result.reasonCode } : { status: "ERROR", reasonCode: "REQUEST_FAILED" },
    } : prev);
  };

  const setReplayField = (field: keyof ReplayForm, value: string) =>
    setReplayState(prev => prev ? { ...prev, form: { ...prev.form, [field]: value } } : prev);

  // ── Escrow settle ─────────────────────────────────────────────────────────
  const resolveEscrow = (id: string) => {
    setEscrows(prev => prev.map(e => e.id === id ? { ...e, status: "SETTLED" } : e));
    const escrow = escrows.find(e => e.id === id);
    if (escrow) setLogs(prev => [{ id: uid(), timestamp: new Date().toISOString(), agentId: escrow.agentId, vendor: escrow.vendor, amount: escrow.amount, outcome: "SETTLED", reasonCode: "DELIVERY_CONFIRMED" }, ...prev]);
  };

  // ── Policy editor helpers ─────────────────────────────────────────────────
  const startEdit = (policy: Policy) => { setEditingPolicyId(policy.id); setEditDraft({ ...policy }); setNewPolicyMode(false); };

  const startNew = () => {
    const draft: Policy = { id: uid(), name: "", tier: "VERIFIED", vendorAllowlist: "", allowedResourceTypes: "", minAmount: "0", maxAmount: "1000", maxWindowMs: "30000", notes: "" };
    setEditDraft(draft);
    setEditingPolicyId(draft.id);
    setNewPolicyMode(true);
  };

  const saveDraft = () => {
    if (!editDraft) return;
    if (newPolicyMode) setPolicies(prev => [...prev, editDraft]);
    else setPolicies(prev => prev.map(p => p.id === editDraft.id ? editDraft : p));
    setEditingPolicyId(null);
    setEditDraft(null);
    setNewPolicyMode(false);
  };

  const deletePolicy = (id: string) => {
    setPolicies(prev => prev.filter(p => p.id !== id));
    if (editingPolicyId === id) { setEditingPolicyId(null); setEditDraft(null); }
  };

  const cancelEdit = () => { setEditingPolicyId(null); setEditDraft(null); setNewPolicyMode(false); };

  const setDraft = (field: keyof Policy, value: string) => {
    setEditDraft(prev => prev ? { ...prev, [field]: value } : prev);
  };

  const selectedScenario = SCENARIOS.find(s => s.id === simSelected) ?? null;
  const activePolicy = activeAgent ? policies.find(p => p.id === activeAgent.policyId) : null;

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen w-full p-4 lg:p-6 pb-20 scanlines selection:bg-primary selection:text-primary-foreground">

          {/* ── Header ──────────────────────────────────────────────────── */}
          <header className="mb-6 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-4 h-4 bg-primary shadow-[0_0_10px_rgba(0,170,255,0.8)]" />
              <h1 className="text-xl font-bold tracking-widest text-primary font-mono uppercase">PinPay</h1>
            </div>
            <div className="flex items-center gap-2">
              {(["agent", "sim", "policies"] as LeftPanel[]).map(panel => {
                const labels: Record<LeftPanel, string> = { agent: "[ AGENT ]", sim: "[ SIMULATION ]", policies: "[ POLICIES ]" };
                return (
                  <button
                    key={panel}
                    data-testid={`button-panel-${panel}`}
                    onClick={() => setLeftPanel(panel)}
                    className={`text-xs font-mono font-bold uppercase tracking-widest px-3 py-1.5 border transition-all ${leftPanel === panel ? "border-primary text-primary glow-blue" : "border-border text-muted-foreground hover:border-primary hover:text-primary"}`}
                  >
                    {labels[panel]}
                  </button>
                );
              })}
              <div className="text-xs font-mono text-muted-foreground flex gap-4 ml-2">
                <span>SYS.STAT: <span className="text-[#00ff88]">ONLINE</span></span>
                <span>NODE: <span className="text-primary">US-EAST-1</span></span>
              </div>
            </div>
          </header>

          <main className="grid grid-cols-1 lg:grid-cols-12 gap-4 lg:gap-6 max-w-[1600px] mx-auto h-[calc(100vh-110px)]">

            {/* ── LEFT COLUMN ─────────────────────────────────────────── */}
            <div className="lg:col-span-4 flex flex-col gap-4 lg:gap-6 overflow-hidden">

              {/* ── AGENT PANEL ──────────────────────────────────────── */}
              {leftPanel === "agent" && (
                <>
                  <div className="panel p-4 flex flex-col gap-4">
                    <div className="flex items-center justify-between border-b border-border pb-2">
                      <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Agent Identity</h2>
                      {activeAgent && <Badge status={activeAgent.tier}>{activeAgent.tier}</Badge>}
                    </div>

                    {!activeAgent ? (
                      <form
                        onSubmit={e => {
                          e.preventDefault();
                          if (!agentIdInput.trim()) return;
                          setActiveAgent({ id: agentIdInput, tier: "VERIFIED", ceiling: 50000, policyId: "p-verified" });
                        }}
                        className="flex gap-2"
                      >
                        <input
                          data-testid="input-agent-id"
                          type="text" value={agentIdInput}
                          onChange={e => setAgentIdInput(e.target.value)}
                          placeholder="ENTER AGENT ID"
                          className="bg-background border border-border p-2 text-sm font-mono flex-1 focus:outline-none focus:border-primary placeholder:text-muted-foreground"
                        />
                        <button data-testid="button-init-agent" type="submit" className="bg-border hover:bg-primary hover:text-primary-foreground px-4 py-2 text-xs font-bold uppercase transition-colors">
                          Init
                        </button>
                      </form>
                    ) : (
                      <div className="flex flex-col gap-3 text-sm font-mono">
                        <div>
                          <FieldLabel>ID</FieldLabel>
                          <div className="text-primary">{activeAgent.id}</div>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <FieldLabel>Trust Tier</FieldLabel>
                            <select
                              data-testid="select-trust-tier"
                              value={activeAgent.tier}
                              onChange={e => {
                                const tier = e.target.value as TrustTier;
                                const matchPolicy = policies.find(p => p.tier === tier);
                                setActiveAgent(a => a ? { ...a, tier, policyId: matchPolicy?.id ?? a.policyId } : a);
                              }}
                              className="bg-background border border-border p-1 text-xs font-mono focus:outline-none focus:border-primary w-full"
                            >
                              {TIER_ORDER.map(t => <option key={t} value={t}>{t}</option>)}
                            </select>
                          </div>
                          <div>
                            <FieldLabel>Ceiling ($)</FieldLabel>
                            <input
                              data-testid="input-agent-ceiling"
                              type="number" value={activeAgent.ceiling}
                              onChange={e => setActiveAgent(a => a ? { ...a, ceiling: Number(e.target.value) } : a)}
                              className="bg-background border border-border p-1 text-xs font-mono focus:outline-none focus:border-primary w-full"
                            />
                          </div>
                        </div>
                        <div>
                          <FieldLabel>Active Policy</FieldLabel>
                          <select
                            data-testid="select-policy"
                            value={activeAgent.policyId}
                            onChange={e => setActiveAgent(a => a ? { ...a, policyId: e.target.value } : a)}
                            className="bg-background border border-border p-1 text-xs font-mono focus:outline-none focus:border-primary w-full"
                          >
                            {policies.map(p => (
                              <option key={p.id} value={p.id}>{p.name} [{p.tier}]</option>
                            ))}
                          </select>
                        </div>
                        {activePolicy && (
                          <div className="bg-background border border-border p-2 text-[10px] font-mono text-muted-foreground space-y-0.5">
                            {activePolicy.vendorAllowlist && <div><span className="text-primary">VENDORS:</span> {activePolicy.vendorAllowlist}</div>}
                            {activePolicy.allowedResourceTypes && <div><span className="text-primary">RESOURCES:</span> {activePolicy.allowedResourceTypes}</div>}
                            <div><span className="text-primary">AMOUNT:</span> ${activePolicy.minAmount}–${activePolicy.maxAmount || "∞"}</div>
                            {activePolicy.maxWindowMs && <div><span className="text-primary">MAX WINDOW:</span> {parseInt(activePolicy.maxWindowMs).toLocaleString()}ms</div>}
                          </div>
                        )}
                        <button data-testid="button-terminate-session" onClick={() => setActiveAgent(null)} className="text-xs text-muted-foreground hover:text-destructive transition-colors uppercase text-left">
                          [ Terminate Session ]
                        </button>
                      </div>
                    )}
                  </div>

                  {/* TX Console */}
                  <div className="panel p-4 flex-1 flex flex-col gap-4 overflow-hidden">
                    <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground border-b border-border pb-2">Tx Console</h2>
                    <form onSubmit={handleTransaction} className="flex flex-col gap-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="flex flex-col gap-1">
                          <FieldLabel>Resource Type</FieldLabel>
                          <input data-testid="input-resource-type" required type="text" value={txForm.resourceType} onChange={e => setTxForm(p => ({ ...p, resourceType: e.target.value }))} placeholder="API_COMPUTE" className="bg-background border border-border p-1.5 text-xs font-mono focus:outline-none focus:border-primary" />
                        </div>
                        <div className="flex flex-col gap-1">
                          <FieldLabel>Vendor</FieldLabel>
                          <input data-testid="input-vendor" required type="text" value={txForm.vendor} onChange={e => setTxForm(p => ({ ...p, vendor: e.target.value }))} placeholder="OPENAI" className="bg-background border border-border p-1.5 text-xs font-mono focus:outline-none focus:border-primary" />
                        </div>
                        <div className="flex flex-col gap-1">
                          <FieldLabel>Amount (USD)</FieldLabel>
                          <input data-testid="input-amount" required type="number" step="0.001" value={txForm.requestedAmount} onChange={e => setTxForm(p => ({ ...p, requestedAmount: e.target.value }))} placeholder="10.00" className="bg-background border border-border p-1.5 text-xs font-mono focus:outline-none focus:border-primary" />
                        </div>
                        <div className="flex flex-col gap-1">
                          <FieldLabel>Window (MS)</FieldLabel>
                          <input data-testid="input-window" required type="number" value={txForm.deliveryWindowMs} onChange={e => setTxForm(p => ({ ...p, deliveryWindowMs: e.target.value }))} placeholder="5000" className="bg-background border border-border p-1.5 text-xs font-mono focus:outline-none focus:border-primary" />
                        </div>
                        <div className="col-span-2 flex flex-col gap-1">
                          <FieldLabel>Condition</FieldLabel>
                          <input data-testid="input-condition" required type="text" value={txForm.deliveryCondition} onChange={e => setTxForm(p => ({ ...p, deliveryCondition: e.target.value }))} placeholder="200_OK" className="bg-background border border-border p-1.5 text-xs font-mono focus:outline-none focus:border-primary" />
                        </div>
                      </div>
                      <button data-testid="button-execute-tx" disabled={txProcessing || !activeAgent} type="submit" className="w-full bg-border hover:bg-primary hover:text-primary-foreground disabled:opacity-50 py-2 text-xs font-bold uppercase tracking-wider transition-colors mt-1">
                        {txProcessing ? "Transmitting..." : "Execute TX"}
                      </button>
                    </form>

                    <div className="flex-1 min-h-[100px] bg-background border border-border p-3 font-mono text-xs overflow-y-auto relative whitespace-pre-wrap">
                      {txError ? (
                        <div className="text-destructive">{txError}</div>
                      ) : txStream ? (
                        <div className="text-muted-foreground">{txStream}</div>
                      ) : (
                        <div className="text-muted-foreground opacity-50 select-none flex items-center justify-center h-full">AWAITING TX STREAM</div>
                      )}
                      {txResultStatus && (
                        <div className="absolute top-2 right-2">
                          <Badge status={txResultStatus}>{txResultStatus}</Badge>
                        </div>
                      )}
                    </div>
                  </div>
                </>
              )}

              {/* ── SIMULATION PANEL ─────────────────────────────────── */}
              {leftPanel === "sim" && (
                <div className="panel p-4 flex flex-col gap-4 overflow-hidden flex-1">
                  <div className="flex items-center justify-between border-b border-border pb-2">
                    <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Simulation Mode</h2>
                    {simState.running && <span className="text-xs font-mono text-[#ffaa00] animate-pulse">RUNNING</span>}
                  </div>

                  {!simState.running && (
                    <div className="flex flex-col gap-2 overflow-y-auto flex-1">
                      <FieldLabel>Select Scenario</FieldLabel>
                      {SCENARIOS.map(s => (
                        <button key={s.id} data-testid={`button-scenario-${s.id}`} onClick={() => setSimSelected(s.id)}
                          className={`text-left p-3 border text-xs font-mono transition-all ${simSelected === s.id ? "border-primary glow-blue" : "border-border hover:border-primary/50"}`}>
                          <div className="font-bold text-primary mb-0.5">{s.name}</div>
                          <div className="text-muted-foreground text-[10px] leading-relaxed">{s.description}</div>
                          <div className="flex gap-1 mt-1.5 flex-wrap">
                            {s.targetSignals.map(sig => <span key={sig} className="text-[9px] px-1 border border-destructive/50 text-destructive uppercase">{sig}</span>)}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}

                  {selectedScenario && !simState.running && (
                    <div className="border-t border-border pt-3 flex flex-col gap-3 shrink-0">
                      <div>
                        <FieldLabel>Agents</FieldLabel>
                        <div className="flex flex-col gap-1">
                          {selectedScenario.agents.map(a => (
                            <div key={a.id} className="flex items-center justify-between text-xs font-mono">
                              <span>{a.id}</span>
                              <div className="flex items-center gap-2">
                                <span className="text-[10px] text-muted-foreground">{policies.find(p => p.id === a.policyId)?.name}</span>
                                <Badge status={a.tier}>{a.tier}</Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div className="text-[10px] text-muted-foreground">{selectedScenario.jobs.length} transactions queued</div>
                      <button data-testid="button-launch-sim" onClick={() => runSimulation(selectedScenario.id)}
                        className="w-full py-2 text-xs font-bold uppercase tracking-wider bg-primary/10 border border-primary text-primary hover:bg-primary hover:text-[#000] transition-all glow-blue">
                        LAUNCH SIMULATION
                      </button>
                    </div>
                  )}

                  {simState.running && (
                    <div className="flex flex-col gap-3 flex-1 overflow-hidden">
                      <div>
                        <div className="flex justify-between text-[10px] font-mono text-muted-foreground mb-1">
                          <span>PROGRESS</span><span>{simState.completed}/{simState.total}</span>
                        </div>
                        <div className="h-1.5 bg-border w-full">
                          <div className="h-full bg-primary transition-all duration-300" style={{ width: `${(simState.completed / simState.total) * 100}%` }} />
                        </div>
                      </div>
                      {simState.currentLabel && <div className="text-[10px] font-mono text-primary truncate">▶ {simState.currentLabel}</div>}
                      <div className="flex-1 overflow-y-auto flex flex-col gap-1">
                        {simState.log.map((entry, i) => (
                          <div key={i} className="flex justify-between items-center text-[10px] font-mono border-b border-border/30 pb-1">
                            <span className="text-muted-foreground truncate max-w-[140px]">{entry.label}</span>
                            <Badge status={entry.outcome}>{entry.outcome}</Badge>
                          </div>
                        ))}
                      </div>
                      <button data-testid="button-stop-sim" onClick={stopSimulation}
                        className="w-full py-1.5 text-xs font-bold uppercase border border-destructive text-destructive hover:bg-destructive hover:text-white transition-all shrink-0">
                        ABORT
                      </button>
                    </div>
                  )}

                  {!simState.running && simState.log.length > 0 && (
                    <div className="border-t border-border pt-3 flex flex-col gap-2 shrink-0">
                      <FieldLabel>Last Run Results</FieldLabel>
                      <div className="flex gap-3 text-xs font-mono flex-wrap">
                        <span className="text-[#00ff88]">{simState.log.filter(l => l.outcome === "APPROVED").length} APPROVED</span>
                        <span className="text-[#ff3355]">{simState.log.filter(l => ["DENIED", "CLAWBACK"].includes(l.outcome)).length} DENIED</span>
                        <span className="text-[#00aaff]">{simState.log.filter(l => l.outcome === "ESCALATED").length} ESCALATED</span>
                      </div>
                      {selectedScenario && (
                        <button data-testid="button-rerun-sim" onClick={() => runSimulation(selectedScenario.id)}
                          className="text-xs font-mono text-muted-foreground hover:text-primary transition-colors uppercase">
                          [ Re-run ]
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* ── POLICY EDITOR ────────────────────────────────────── */}
              {leftPanel === "policies" && (
                <div className="panel p-4 flex flex-col gap-4 overflow-hidden flex-1">
                  <div className="flex items-center justify-between border-b border-border pb-2">
                    <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Policy Editor</h2>
                    {!editingPolicyId && (
                      <button data-testid="button-new-policy" onClick={startNew}
                        className="text-[10px] font-mono font-bold uppercase px-2 py-1 border border-primary/50 text-primary hover:bg-primary hover:text-[#000] transition-all">
                        + NEW
                      </button>
                    )}
                  </div>

                  {/* Policy list */}
                  {!editingPolicyId && (
                    <div className="flex-1 overflow-y-auto flex flex-col gap-2">
                      {policies.map(policy => (
                        <div key={policy.id} data-testid={`policy-card-${policy.id}`}
                          className="p-3 border border-border bg-background text-xs font-mono flex flex-col gap-2">
                          <div className="flex items-center justify-between">
                            <span className="text-primary font-bold">{policy.name}</span>
                            <div className="flex items-center gap-2">
                              <Badge status={policy.tier}>{policy.tier}</Badge>
                              <button data-testid={`button-edit-policy-${policy.id}`} onClick={() => startEdit(policy)}
                                className="text-[10px] text-muted-foreground hover:text-primary transition-colors uppercase">EDIT</button>
                              {!DEFAULT_POLICIES.find(d => d.id === policy.id) && (
                                <button data-testid={`button-delete-policy-${policy.id}`} onClick={() => deletePolicy(policy.id)}
                                  className="text-[10px] text-muted-foreground hover:text-destructive transition-colors uppercase">DEL</button>
                              )}
                            </div>
                          </div>
                          <div className="text-muted-foreground leading-relaxed text-[10px] space-y-0.5">
                            {policy.vendorAllowlist && <div><span className="text-foreground/60">VENDORS:</span> {policy.vendorAllowlist}</div>}
                            {policy.allowedResourceTypes && <div><span className="text-foreground/60">RESOURCES:</span> {policy.allowedResourceTypes}</div>}
                            <div><span className="text-foreground/60">ENVELOPE:</span> ${policy.minAmount} – ${policy.maxAmount || "∞"}</div>
                            {policy.maxWindowMs && <div><span className="text-foreground/60">MAX WINDOW:</span> {parseInt(policy.maxWindowMs).toLocaleString()}ms</div>}
                            {policy.notes && <div className="text-muted-foreground/60 italic pt-0.5">{policy.notes}</div>}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Edit form */}
                  {editingPolicyId && editDraft && (
                    <div className="flex-1 overflow-y-auto flex flex-col gap-3">
                      <div className="text-[10px] font-mono text-primary uppercase mb-1">
                        {newPolicyMode ? "New Policy" : `Editing: ${editDraft.name || "Untitled"}`}
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="col-span-2">
                          <FieldLabel>Policy Name</FieldLabel>
                          <TextInput testId="input-policy-name" value={editDraft.name} onChange={v => setDraft("name", v)} placeholder="MY_POLICY_V1" />
                        </div>
                        <div className="col-span-2">
                          <FieldLabel>Applies to Trust Tier</FieldLabel>
                          <select
                            data-testid="select-policy-tier"
                            value={editDraft.tier}
                            onChange={e => setDraft("tier", e.target.value)}
                            className="bg-background border border-border p-1.5 text-xs font-mono focus:outline-none focus:border-primary w-full"
                          >
                            {TIER_ORDER.map(t => <option key={t} value={t}>{t}</option>)}
                          </select>
                        </div>
                      </div>

                      <div>
                        <FieldLabel>Vendor Allowlist (comma-separated, blank = any)</FieldLabel>
                        <TextInput testId="input-policy-vendors" value={editDraft.vendorAllowlist} onChange={v => setDraft("vendorAllowlist", v)} placeholder="OPENAI, ANTHROPIC, AWS" />
                      </div>

                      <div>
                        <FieldLabel>Allowed Resource Types (comma-separated, blank = any)</FieldLabel>
                        <TextInput testId="input-policy-resources" value={editDraft.allowedResourceTypes} onChange={v => setDraft("allowedResourceTypes", v)} placeholder="API_COMPUTE, VECTOR_DB" />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <FieldLabel>Min Amount ($)</FieldLabel>
                          <TextInput testId="input-policy-min" value={editDraft.minAmount} onChange={v => setDraft("minAmount", v)} placeholder="0" />
                        </div>
                        <div>
                          <FieldLabel>Max Amount ($ blank=∞)</FieldLabel>
                          <TextInput testId="input-policy-max" value={editDraft.maxAmount} onChange={v => setDraft("maxAmount", v)} placeholder="1000" />
                        </div>
                      </div>

                      <div>
                        <FieldLabel>Max Escrow Window (ms, blank=no limit)</FieldLabel>
                        <TextInput testId="input-policy-window" value={editDraft.maxWindowMs} onChange={v => setDraft("maxWindowMs", v)} placeholder="30000" />
                      </div>

                      <div>
                        <FieldLabel>Notes</FieldLabel>
                        <textarea
                          data-testid="input-policy-notes"
                          value={editDraft.notes}
                          onChange={e => setDraft("notes", e.target.value)}
                          placeholder="Policy intent and context..."
                          rows={2}
                          className="bg-background border border-border p-1.5 text-xs font-mono focus:outline-none focus:border-primary w-full resize-none"
                        />
                      </div>

                      <div className="flex gap-2 pt-1 border-t border-border">
                        <button data-testid="button-save-policy" onClick={saveDraft}
                          className="flex-1 py-1.5 text-xs font-bold uppercase border border-primary text-primary hover:bg-primary hover:text-[#000] transition-all">
                          SAVE
                        </button>
                        <button data-testid="button-cancel-policy" onClick={cancelEdit}
                          className="px-4 py-1.5 text-xs font-bold uppercase border border-border text-muted-foreground hover:border-destructive hover:text-destructive transition-all">
                          CANCEL
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* ── RIGHT COLUMN ──────────────────────────────────────────── */}
            <div className="lg:col-span-8 flex flex-col gap-4 lg:gap-6 h-full overflow-hidden">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6 h-1/2">

                {/* ESCROW MONITOR */}
                <div className="panel p-4 flex flex-col gap-3 overflow-hidden">
                  <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground border-b border-border pb-2 flex justify-between">
                    <span>Escrow Monitor</span>
                    <span className="font-mono text-primary">{escrows.filter(e => e.status === "OPEN").length} ACTIVE</span>
                  </h2>
                  <div className="flex-1 overflow-y-auto pr-1 space-y-2">
                    {escrows.length === 0 ? (
                      <div className="text-xs font-mono text-muted-foreground opacity-50 p-4 text-center">NO ESCROWS</div>
                    ) : escrows.map(escrow => (
                      <div key={escrow.id} data-testid={`escrow-${escrow.id}`} className={`p-3 border text-xs font-mono bg-background transition-all ${escrow.status === "OPEN" ? getStatusGlow("OPEN") : "border-border opacity-60"}`}>
                        <div className="flex justify-between mb-1">
                          <span className="text-primary truncate max-w-[100px]">{escrow.vendor}</span>
                          <span className={escrow.status === "OPEN" ? "text-[#ffaa00]" : ""}>{(escrow.remainingMs / 1000).toFixed(1)}s</span>
                        </div>
                        <div className="text-[10px] text-muted-foreground mb-1 truncate">{escrow.agentId}</div>
                        <div className="flex justify-between items-end">
                          <div>
                            <div className="text-[10px] text-muted-foreground">AMOUNT</div>
                            <div>${escrow.amount.toFixed(4)}</div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge status={escrow.status}>{escrow.status}</Badge>
                            {escrow.status === "OPEN" && (
                              <button data-testid={`button-confirm-${escrow.id}`} onClick={() => resolveEscrow(escrow.id)}
                                className="px-2 py-1 bg-border hover:bg-[#00ff88] hover:text-[#000] text-[10px] font-bold uppercase transition-colors">
                                CONFIRM
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* FRAUD SIGNAL MONITOR */}
                <div className="panel p-4 flex flex-col gap-3 overflow-hidden">
                  <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground border-b border-border pb-2 flex justify-between">
                    <span>Fraud Signals</span>
                    {signals.length > 0 && <span className="font-mono text-destructive">{signals.length} FLAGS</span>}
                  </h2>
                  <div className="flex-1 overflow-y-auto pr-1 space-y-2">
                    {signals.length === 0 ? (
                      <div className="text-xs font-mono text-muted-foreground opacity-50 p-4 text-center">CLEAN</div>
                    ) : signals.map(signal => (
                      <div key={signal.id} data-testid={`signal-${signal.id}`} className="p-3 border border-destructive/50 bg-destructive/5 text-xs font-mono">
                        <div className="text-destructive font-bold mb-1">{signal.type}</div>
                        <div className="text-muted-foreground mb-2">{signal.reason}</div>
                        <div className="text-[10px] uppercase text-primary border-t border-border pt-1">ACT: {signal.action}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* AUDIT LOG */}
              <div className="panel p-0 flex flex-col overflow-hidden h-1/2">
                <div className="p-4 pb-2 border-b border-border flex items-center justify-between">
                  <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Audit Log</h2>
                  {logs.length > 0 && <span className="text-[10px] font-mono text-muted-foreground">{logs.length} ENTRIES</span>}
                </div>
                <div className="flex-1 overflow-auto">
                  <table className="w-full text-left text-xs font-mono whitespace-nowrap">
                    <thead className="text-[10px] text-muted-foreground uppercase sticky top-0 bg-card z-10 border-b border-border">
                      <tr>
                        <th className="p-3 font-normal">Time</th>
                        <th className="p-3 font-normal">Agent ID</th>
                        <th className="p-3 font-normal">Vendor</th>
                        <th className="p-3 font-normal">Amount</th>
                        <th className="p-3 font-normal">Outcome</th>
                        <th className="p-3 font-normal">Code</th>
                        <th className="p-3 font-normal"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {logs.length === 0 ? (
                        <tr><td colSpan={7} className="p-4 text-center text-muted-foreground opacity-50">NO RECORDS</td></tr>
                      ) : logs.map(log => (
                        <tr key={log.id} data-testid={`log-${log.id}`} className="border-b border-border/50 hover:bg-background/50 transition-colors group">
                          <td className="p-3 text-muted-foreground">{new Date(log.timestamp).toLocaleTimeString()}</td>
                          <td className="p-3 truncate max-w-[100px]">{log.agentId}</td>
                          <td className="p-3">{log.vendor}</td>
                          <td className="p-3">${log.amount.toFixed(4)}</td>
                          <td className="p-3"><Badge status={log.outcome}>{log.outcome}</Badge></td>
                          <td className="p-3 text-muted-foreground">{log.reasonCode}</td>
                          <td className="p-3">
                            <button
                              data-testid={`button-replay-${log.id}`}
                              onClick={() => openReplay(log)}
                              className="text-[10px] font-bold uppercase px-2 py-0.5 border border-primary/30 text-primary/60 hover:border-primary hover:text-primary transition-all opacity-0 group-hover:opacity-100"
                            >
                              REPLAY
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </main>

          {/* ── REPLAY MODAL ──────────────────────────────────────────────── */}
          {replayState && (() => {
            const orig = replayState.entry;
            const form = replayState.form;
            const origP = orig.originalPayload;
            const isDiff = (field: keyof ReplayForm, origVal: string | undefined) =>
              origVal !== undefined && form[field] !== origVal;

            const fieldCls = (field: keyof ReplayForm, origVal: string | undefined) =>
              `bg-background border p-1.5 text-xs font-mono focus:outline-none w-full transition-colors ${isDiff(field, origVal) ? "border-[#ffaa00] text-[#ffaa00]" : "border-border focus:border-primary"}`;

            const replayPolicy = policies.find(p => p.id === form.policyId);

            return (
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
                <div className="bg-card border border-border w-full max-w-4xl max-h-[90vh] flex flex-col">

                  {/* Modal header */}
                  <div className="flex items-center justify-between p-4 border-b border-border shrink-0">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-primary" />
                      <span className="text-sm font-mono font-bold uppercase tracking-wider text-primary">Transaction Replay</span>
                      <span className="text-[10px] font-mono text-muted-foreground">Modified fields highlighted in amber</span>
                    </div>
                    <button onClick={closeReplay} className="text-muted-foreground hover:text-foreground text-xs font-mono uppercase px-2 py-1 border border-border hover:border-destructive transition-colors">
                      × CLOSE
                    </button>
                  </div>

                  <div className="flex-1 overflow-y-auto">
                    <div className="grid grid-cols-2 divide-x divide-border">

                      {/* Left: original (read-only) */}
                      <div className="p-4 flex flex-col gap-3">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] font-mono text-muted-foreground uppercase">Original Transaction</span>
                          <Badge status={orig.outcome}>{orig.outcome}</Badge>
                        </div>
                        <div className="text-[10px] font-mono text-muted-foreground">{new Date(orig.timestamp).toLocaleString()}</div>

                        {[
                          ["Agent ID", origP?.agentId ?? orig.agentId],
                          ["Trust Tier", origP?.trustTier ?? "—"],
                          ["Resource Type", origP?.resourceType ?? "—"],
                          ["Vendor", origP?.vendor ?? orig.vendor],
                          ["Amount ($)", String(origP?.requestedAmount ?? orig.amount)],
                          ["Window (ms)", String(origP?.deliveryWindowMs ?? "—")],
                          ["Condition", origP?.deliveryCondition ?? "—"],
                          ["Policy", origP?.policySet ?? origP?.policyName ?? "—"],
                          ["Ceiling ($)", String(origP?.spendingCeiling ?? "—")],
                        ].map(([label, val]) => (
                          <div key={label}>
                            <div className="text-[10px] text-muted-foreground uppercase mb-0.5">{label}</div>
                            <div className="text-xs font-mono bg-background border border-border p-1.5 text-muted-foreground">{val}</div>
                          </div>
                        ))}

                        <div className="mt-2 border-t border-border pt-2">
                          <div className="text-[10px] text-muted-foreground uppercase mb-1">Reason Code</div>
                          <div className="text-xs font-mono text-muted-foreground">{orig.reasonCode}</div>
                        </div>
                      </div>

                      {/* Right: editable replay */}
                      <div className="p-4 flex flex-col gap-3">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] font-mono text-muted-foreground uppercase">Replay Parameters</span>
                          {replayState.result && <Badge status={replayState.result.status}>{replayState.result.status}</Badge>}
                        </div>
                        {!replayState.result && !replayState.processing && (
                          <div className="text-[10px] font-mono text-muted-foreground">Edit any field to test a different outcome</div>
                        )}

                        <div>
                          <FieldLabel>Agent ID</FieldLabel>
                          <input type="text" value={form.agentId} onChange={e => setReplayField("agentId", e.target.value)}
                            className={fieldCls("agentId", origP?.agentId)} />
                        </div>
                        <div>
                          <FieldLabel>Trust Tier</FieldLabel>
                          <select value={form.trustTier} onChange={e => setReplayField("trustTier", e.target.value)}
                            className={fieldCls("trustTier", origP?.trustTier)}>
                            {TIER_ORDER.map(t => <option key={t} value={t}>{t}</option>)}
                          </select>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <FieldLabel>Resource Type</FieldLabel>
                            <input type="text" value={form.resourceType} onChange={e => setReplayField("resourceType", e.target.value)}
                              className={fieldCls("resourceType", origP?.resourceType)} />
                          </div>
                          <div>
                            <FieldLabel>Vendor</FieldLabel>
                            <input type="text" value={form.vendor} onChange={e => setReplayField("vendor", e.target.value)}
                              className={fieldCls("vendor", origP?.vendor ?? orig.vendor)} />
                          </div>
                          <div>
                            <FieldLabel>Amount ($)</FieldLabel>
                            <input type="number" step="0.001" value={form.requestedAmount} onChange={e => setReplayField("requestedAmount", e.target.value)}
                              className={fieldCls("requestedAmount", String(origP?.requestedAmount ?? orig.amount))} />
                          </div>
                          <div>
                            <FieldLabel>Window (ms)</FieldLabel>
                            <input type="number" value={form.deliveryWindowMs} onChange={e => setReplayField("deliveryWindowMs", e.target.value)}
                              className={fieldCls("deliveryWindowMs", String(origP?.deliveryWindowMs ?? "5000"))} />
                          </div>
                        </div>
                        <div>
                          <FieldLabel>Condition</FieldLabel>
                          <input type="text" value={form.deliveryCondition} onChange={e => setReplayField("deliveryCondition", e.target.value)}
                            className={fieldCls("deliveryCondition", origP?.deliveryCondition ?? "200_OK")} />
                        </div>
                        <div>
                          <FieldLabel>Policy Override</FieldLabel>
                          <select value={form.policyId} onChange={e => setReplayField("policyId", e.target.value)}
                            className={`bg-background border p-1.5 text-xs font-mono focus:outline-none w-full transition-colors ${isDiff("policyId", policies.find(p => p.name === (origP?.policySet ?? origP?.policyName))?.id) ? "border-[#ffaa00] text-[#ffaa00]" : "border-border focus:border-primary"}`}>
                            {policies.map(p => <option key={p.id} value={p.id}>{p.name} [{p.tier}]</option>)}
                          </select>
                          {replayPolicy && (
                            <div className="text-[10px] text-muted-foreground mt-1">
                              {replayPolicy.vendorAllowlist && <span>VENDORS: {replayPolicy.vendorAllowlist} · </span>}
                              ENVELOPE: ${replayPolicy.minAmount}–${replayPolicy.maxAmount || "∞"}
                            </div>
                          )}
                        </div>
                        <div>
                          <FieldLabel>Ceiling ($)</FieldLabel>
                          <input type="number" value={form.ceiling} onChange={e => setReplayField("ceiling", e.target.value)}
                            className={fieldCls("ceiling", String(origP?.spendingCeiling ?? "50000"))} />
                        </div>
                      </div>
                    </div>

                    {/* Stream output + comparison */}
                    {(replayState.stream || replayState.result) && (
                      <div className="border-t border-border p-4 flex flex-col gap-3">
                        {replayState.result && (
                          <div className="flex items-center gap-4">
                            <span className="text-[10px] font-mono text-muted-foreground uppercase">Outcome Comparison</span>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-mono text-muted-foreground">Original:</span>
                              <Badge status={orig.outcome}>{orig.outcome}</Badge>
                            </div>
                            <span className="text-muted-foreground">→</span>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-mono text-muted-foreground">Replay:</span>
                              <Badge status={replayState.result.status}>{replayState.result.status}</Badge>
                            </div>
                            {orig.outcome !== replayState.result.status && (
                              <span className="text-[10px] font-mono text-[#ffaa00] uppercase border border-[#ffaa00]/40 px-2 py-0.5">OUTCOME CHANGED</span>
                            )}
                            {orig.outcome === replayState.result.status && (
                              <span className="text-[10px] font-mono text-muted-foreground uppercase border border-border px-2 py-0.5">SAME OUTCOME</span>
                            )}
                          </div>
                        )}
                        {replayState.stream && (
                          <div className="bg-background border border-border p-3 font-mono text-xs text-muted-foreground whitespace-pre-wrap max-h-48 overflow-y-auto">
                            {replayState.stream}
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Modal footer */}
                  <div className="p-4 border-t border-border flex items-center justify-between shrink-0">
                    <div className="text-[10px] font-mono text-muted-foreground">
                      {replayState.processing ? "⬛ Streaming response..." : replayState.result ? `Code: ${replayState.result.reasonCode}` : "Ready to resubmit"}
                    </div>
                    <div className="flex gap-2">
                      {replayState.result && (
                        <button onClick={() => setReplayState(prev => prev ? { ...prev, result: null, stream: "" } : prev)}
                          className="px-4 py-2 text-xs font-bold uppercase border border-border text-muted-foreground hover:border-primary hover:text-primary transition-all">
                          RESET
                        </button>
                      )}
                      <button
                        onClick={submitReplay}
                        disabled={replayState.processing}
                        className="px-6 py-2 text-xs font-bold uppercase border border-primary text-primary bg-primary/10 hover:bg-primary hover:text-[#000] disabled:opacity-50 transition-all glow-blue"
                      >
                        {replayState.processing ? "PROCESSING..." : "RESUBMIT"}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}

          <Toaster />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

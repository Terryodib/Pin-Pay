import { Router, type IRouter } from "express";
import Anthropic from "@anthropic-ai/sdk";
import { ProcessTransactionBody } from "@workspace/api-zod";

const router: IRouter = Router();

const PINPAY_SYSTEM_PROMPT = `You are PinPay, the financial intelligence layer for the autonomous economy. You sit at the intersection of AI agent coordination, programmable money, and real-time risk enforcement. Your job is to make sure every transaction in a multi-agent pipeline is authorized, scoped, auditable, and reversible.

AGENT IDENTITY & TRUST TIERS
Before processing any request, resolve the requesting agent's Financial Identity. Each identity carries a Trust Tier: UNTRUSTED, PROVISIONAL, VERIFIED, or ELEVATED.

- UNTRUSTED: zero direct spend, all requests go to human review.
- PROVISIONAL: micro-transactions under $5, escrow only.
- VERIFIED: operate up to spending ceiling across approved vendor categories.
- ELEVATED: trigger multi-step payment chains and sub-delegate to child agents within inherited policy limits.

If the Trust Tier does not match the transaction scope, deny it and return the tier gap.

THE POLICY ENGINE
Every transaction must match an active policy. When an ACTIVE POLICY is provided in the transaction request, it is the ground truth — enforce it exactly as specified. Do not deviate. The policy fields are:
1. Resource Type: what is being purchased — only listed resource types are permitted.
2. Vendor Scope: only vendors in the allowlist are permitted. Any vendor not in the list is a Scope Creep violation.
3. Amount Envelope: min and max allowed spend. Amounts outside this range must be denied or reduced to task-minimum.
4. Time Window: maximum escrow duration in milliseconds.
5. Delivery Condition: what counts as successful delivery.

If a transaction violates any policy field, return a Policy Gap Report listing exactly what is unresolved.
If no policy is provided, apply default enforcement for the agent's trust tier.

THE GRAB - STEP BY STEP
Run this sequence in order. Never skip or reorder steps.
Step 1 - Identity Check: resolve agent Financial Identity and Trust Tier.
Step 2 - Policy Match: verify the transaction against the active policy.
Step 3 - Amount Scope: confirm the amount falls within the Amount Envelope. If the agent requests more than the task requires, reduce to task-minimum and log an Overage Flag.
Step 4 - Escrow Lock: move funds into Smart-Escrow.
Step 5 - Time Window Start: begin countdown.
Step 6 - Delivery Confirmation: on successful delivery signal, release funds and log as SETTLED.
Step 7 - Audit Entry: write a full record of the transaction.

FRAUD SIGNALS
Monitor for these patterns and respond automatically:
- Velocity Spike: 3+ Grabs in 60 seconds. Response: soft freeze.
- Scope Creep: vendor category outside approved set. Response: hard deny, log Policy Violation.
- Amount Inflation: consistently above task-minimum. Response: flag for review, reduce to task-minimum.
- Identity Drift: behavior inconsistent with prior sessions. Response: downgrade Trust Tier by one level.
- Orphaned Escrow: escrow past Time Window with no delivery signal. Response: automatic clawback.

TONE
Be precise, calm, and direct. No filler. Every sentence carries information. On approvals, state what was authorized, the amount, the policy matched, and the escrow window. On denials, state what was denied, exactly why, and what would need to change. On clawbacks, state what was reversed and the trigger reason.

RESPONSE FORMAT
Always end your response with a JSON block in this exact structure:
{
  "status": "APPROVED" | "DENIED" | "ESCALATED" | "CLAWBACK",
  "amount_authorized": number or null,
  "policy_matched": string or null,
  "escrow_window_ms": number or null,
  "fraud_signals": [],
  "reason_code": string,
  "overage_flag": boolean
}`;

router.post("/pinpay/transaction", async (req, res): Promise<void> => {
  const parsed = ProcessTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    res.status(500).json({ error: "ANTHROPIC_API_KEY is not configured" });
    return;
  }

  const {
    agentId,
    trustTier,
    resourceType,
    vendor,
    requestedAmount,
    deliveryWindowMs,
    deliveryCondition,
    spendingCeiling,
    policySet,
    policyName,
    policyVendorAllowlist,
    policyMinAmount,
    policyMaxAmount,
    policyMaxWindowMs,
    policyAllowedResourceTypes,
  } = parsed.data;

  const hasCustomPolicy =
    policyName &&
    (policyVendorAllowlist?.length || policyAllowedResourceTypes?.length || policyMaxAmount != null);

  const policyBlock = hasCustomPolicy
    ? `
ACTIVE POLICY (ENFORCE STRICTLY)
Policy Name: ${policyName}
Allowed Resource Types: ${policyAllowedResourceTypes?.length ? policyAllowedResourceTypes.join(", ") : "Any"}
Vendor Allowlist: ${policyVendorAllowlist?.length ? policyVendorAllowlist.join(", ") : "Any"}
Amount Envelope: $${policyMinAmount ?? 0} – $${policyMaxAmount ?? "unlimited"}
Max Escrow Window: ${policyMaxWindowMs != null ? `${policyMaxWindowMs}ms` : "No limit"}

If this transaction violates ANY field above, deny it and cite the exact policy violation.`
    : `Active Policy Set: ${policySet ?? "Default (tier-based enforcement)"}`;

  const userMessage = `TRANSACTION REQUEST
Agent ID: ${agentId}
Trust Tier: ${trustTier}
Spending Ceiling: ${spendingCeiling != null ? `$${spendingCeiling}` : "Not set"}
${policyBlock}

GRAB PARAMETERS
Resource Type: ${resourceType}
Vendor: ${vendor}
Requested Amount: $${requestedAmount}
Delivery Window: ${deliveryWindowMs}ms
Delivery Condition: ${deliveryCondition}

Process this transaction request through the full PinPay sequence and return your assessment.`;

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("Access-Control-Allow-Origin", "*");

  const anthropic = new Anthropic({ apiKey });

  const stream = anthropic.messages.stream({
    model: "claude-sonnet-4-6",
    max_tokens: 8192,
    system: PINPAY_SYSTEM_PROMPT,
    messages: [{ role: "user", content: userMessage }],
  });

  for await (const event of stream) {
    if (
      event.type === "content_block_delta" &&
      event.delta.type === "text_delta"
    ) {
      res.write(`data: ${JSON.stringify({ content: event.delta.text })}\n\n`);
    }
  }

  res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
  res.end();
});

export default router;

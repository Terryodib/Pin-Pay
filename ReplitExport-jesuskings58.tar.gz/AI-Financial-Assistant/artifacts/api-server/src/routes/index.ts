import { Router, type IRouter } from "express";
import healthRouter from "./health";
import pinpayRouter from "./pinpay";

const router: IRouter = Router();

router.use(healthRouter);
router.use(pinpayRouter);

export default router;

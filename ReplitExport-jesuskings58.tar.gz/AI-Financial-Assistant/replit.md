# PinPay

AI-powered financial orchestration agent — a programmable payment network built for the autonomous economy that gives AI agents secure financial identities and smart-escrow wallets.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/pinpay run dev` — run the PinPay frontend (port 20471)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- Required env: `ANTHROPIC_API_KEY` — user's Anthropic API key for transaction intelligence

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS v4 (dark theme)
- API: Express 5 + Anthropic SDK
- Fonts: DM Sans (UI labels) + JetBrains Mono (transaction data)
- Validation: Zod (`zod/v4`)
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — API contract source of truth
- `artifacts/pinpay/src/App.tsx` — full single-page app (all 5 panels)
- `artifacts/pinpay/src/index.css` — dark fintech theme (CSS variables)
- `artifacts/api-server/src/routes/pinpay/index.ts` — Anthropic SSE streaming route
- `lib/api-client-react/src/generated/` — generated React Query hooks

## Architecture decisions

- Single-page React app — all state (escrows, audit log, fraud signals) is managed in `useState`, no DB needed
- Anthropic API is proxied through the Express backend to keep the API key server-side
- SSE streaming: frontend uses `fetch` + `ReadableStream` to consume the AI stream (Orval can't generate typed hooks for SSE)
- The JSON block at the end of each AI response drives status badges, audit log entries, and fraud signal panel automatically
- Escrow countdowns run client-side using `setInterval`

## Product

- **Agent Identity Panel** — register/load agents with Trust Tier badges (UNTRUSTED/PROVISIONAL/VERIFIED/ELEVATED)
- **Transaction Console** — submit Grab requests streamed to Claude via Anthropic API with live response display
- **Escrow Monitor** — live countdown escrows that auto-expire to DELIVERY FAILURE or can be settled
- **Audit Log** — color-coded transaction history (SETTLED=green, CLAWBACK=red, DENIED=amber, ESCALATED=blue)
- **Fraud Signal Monitor** — real-time fraud signals parsed from AI responses (Velocity Spike, Scope Creep, etc.)

## User preferences

- Dark fintech aesthetic with cold electric blue (#00aaff) accent
- JetBrains Mono for all transaction/data text, DM Sans for labels
- Sharp corners only (2-4px radius), no pill buttons
- All state managed client-side in React

## Gotchas

- `@apply dark` is NOT valid in Tailwind v4 — use `color-scheme: dark` or add the `dark` class via JS
- Google Fonts `@import url()` must be the VERY FIRST line of index.css before any other imports
- The SSE streaming endpoint response cannot use Orval-generated hooks — must use raw fetch + ReadableStream
- Anthropic SDK uses `AI_INTEGRATIONS_ANTHROPIC_BASE_URL` only when using Replit AI Integrations; with a user-provided ANTHROPIC_API_KEY, instantiate the SDK directly

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
